# R Script

파일           | 내용
:------------- |:-------------
[Script_Part01.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part01.r) | 01 단어 빈도 분석
[Script_Part02.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part02.r) | 02 형태소 분석기를 이용한 단어 빈도 분석
[Script_Part03.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part03.r) | 03 비교 분석
[Script_Part04.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part04.r) | 04 감정 분석
[Script_Part05.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part05.r) | 05 의미망 분석
[Script_Part06.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part06.r) | 06 토픽 모델링
[Script_Part07.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part07.r) | 07 텍스트 마이닝 프로젝트:  타다 금지법 기사 댓글 분석
[Script_Part08.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Part08.r) | 08 텍스트 마이닝 프로젝트: 차기 대선 주자 SNS 여론 분석
[Script_Summary.r](https://github.com/youngwoos/Doit_textmining/blob/main/Script/Script_Summary.r) | 01~06 정리하기
