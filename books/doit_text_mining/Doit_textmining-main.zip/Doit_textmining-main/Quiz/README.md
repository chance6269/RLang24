# 분석 도전 정답

파일           | 내용
:------------- |:-------------
[Quiz_Part01.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part01.md) | 01 단어 빈도 분석
[Quiz_Part02.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part02.md) | 02 형태소 분석기를 이용한 단어 빈도 분석
[Quiz_Part03.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part03.md) | 03 비교 분석
[Quiz_Part04.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part04.md) | 04 감정 분석
[Quiz_Part05.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part05.md) | 05 의미망 분석
[Quiz_Part06.md](https://github.com/youngwoos/Doit_textmining/blob/main/Quiz/Quiz_Part06.md) | 06 토픽 모델링

