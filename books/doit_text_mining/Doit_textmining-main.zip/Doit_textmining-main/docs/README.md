# 강의용 프리젠테이션 자료

파일           | 내용
:------------- |:-------------
[01-wordFrequency.html](https://youngwoos.github.io/Doit_textmining/01-wordFrequency.html)| 01 단어 빈도 분석
[02-morphologicalAnalysis.html](https://youngwoos.github.io/Doit_textmining/02-morphologicalAnalysis.html)| 02 형태소 분석기를 이용한 단어 빈도 분석
[03-comparing.html](https://youngwoos.github.io/Doit_textmining/03-comparing.html)| 03 비교 분석
[04-sentimentAnalysis.html](https://youngwoos.github.io/Doit_textmining/04-sentimentAnalysis.html)| 04 감정 분석
[05-co-occurrenceAnalysis](https://youngwoos.github.io/Doit_textmining/05/05-co-occurrenceAnalysis.html)| 05 의미망 분석
[06-topicModeling.html](https://youngwoos.github.io/Doit_textmining/06/06-topicModeling.html)| 06 토픽 모델링
[07-project1.html](https://youngwoos.github.io/Doit_textmining/07-project1.html)| 07 프로젝트: 타다 금지법 기사 댓글 분석
[08-project2.html](https://youngwoos.github.io/Doit_textmining/08-project2.html)| 08 프로젝트: 차기 대선 주자 SNS 여론 분석
---

- 슬라이드는 크롬에 최적화되어있습니다. 
  - [크롬 다운로드](https://www.google.com/chrome/)
- [Ctrl]+[P]로 인쇄하면 PDF로 저장할 수 있습니다.
- [o]를 누르면 전체 슬라이드를 한눈에 볼 수 있습니다.
- 자유롭게 수정하고 배포하셔도 됩니다.
